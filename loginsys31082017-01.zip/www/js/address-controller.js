var BookIt = BookIt || {};

BookIt.AddressController = function () {

    this.$addressPage = null;

    this.$btnSubmit = null;

    this.$user_address = null;

    this.$ctnErr = null;

    this.mainMenuPageId = null;

};

BookIt.AddressController.prototype.init = function () {

    this.$addressPage = $("#page-changeAddress");

    this.mainMenuPageId = "#page-main-menu";

    this.$btnSubmit = $("#btn-submit", this.$addressPage);

    this.$ctnErr = $("#ctn-err", this.$addressPage);

    this.$user_address = $("#user_address", this.$addressPage);
};

BookIt.SignInController.prototype.resetaddressForm = function () {

    var invisibleStyle = "bi-invisible",

        invalidInputStyle = "bi-invalid-input";

    this.$ctnErr.html("");

    this.$ctnErr.removeClass().addClass(invisibleStyle);

    this.$user_address.removeClass(invalidInputStyle);
    this.$user_address.val("");
};


BookIt.AddressController.prototype.onaddressCommand = function () {

    var me = this,

        user_address = me.$user_address.val().trim(),
		 invalidInput = false,

        invisibleStyle = "bi-invisible",

        invalidInputStyle = "bi-invalid-input";

    // Reset styles.

    me.$ctnErr.removeClass().addClass(invisibleStyle);

    me.$user_address.removeClass(invalidInputStyle);

    // Flag each invalid field.

    if (user_address.length === 0) {

        me.$user_address.addClass(invalidInputStyle);

        invalidInput = true;

    }

    // Make sure that all the required fields have values.

    if (invalidInput) {

        me.$ctnErr.html("<p>Please enter all the required fields.</p>");

        me.$ctnErr.addClass("bi-ctn-err").slideDown();

        return;

    }
    $.mobile.loading("show");

    $.ajax({

        type: 'POST',

        url: BookIt.Settings.signInUrl,

        data: "user_address=" + user_address ,

        success: function (resp) {

            $.mobile.loading("hide");
			//alert(resp.status);
            if (resp.status == 1) {
//alert('here');
               
				window.localStorage.address=resp.address;
                $.mobile.navigate(me.mainMenuPageId);

                return;

            } 
			else {

                if (resp.msg) {

                    switch (resp.msg) {

                        case "Invalid":

                        // TODO: Use a friendlier error message below.

                            me.$ctnErr.html("<p>Oops! LoginApp had a problem and could not log you on.  Please try again in a few minutes.</p>");

                            me.$ctnErr.addClass("bi-ctn-err").slideDown();

                            break;

                        case BookIt.ApiMessages.INVALID_PWD:

                        case "Error":

                            me.$ctnErr.html("<p> Please try again.</p>");

                            me.$ctnErr.addClass("bi-ctn-err").slideDown();

                            me.$user_address

.addClass(invalidInputStyle);

                            break;

                    }

                }

            }

        },

        error: function (e) {

            $.mobile.loading("hide");

            console.log(e.message);

            // TODO: Use a friendlier error message below.

            me.$ctnErr.html("<p>Oops! LoginAp had a problem and could not log you on.  Please try again in a few minutes.</p>");

            me.$ctnErr.addClass("bi-ctn-err").slideDown();

        }

    });

};