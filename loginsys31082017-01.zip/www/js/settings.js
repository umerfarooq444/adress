﻿var BookIt = BookIt || {};
BookIt.Settings = BookIt.Settings || {};
BookIt.Settings.signInUrl = "http://devp.goldteam.co.uk/admin/restApi/rest_loginEnable.php"; //"http://127.0.0.1:30000/api/account/register";